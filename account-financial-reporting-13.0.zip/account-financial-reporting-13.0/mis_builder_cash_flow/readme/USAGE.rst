To use this module, you need to:

#. Go to Accounting > Reports > MIS Reporting > MIS Reports and choose "Cash Flow" report
#. You can add forecast lines on Accounting > Reports > MIS Reporting > Cash Flow Forecast Line
