
Users willing to access to this report should have proper Accounting & Finance rights:

#. Go to *Settings / Users* and edit your user to add the corresponding access rights as follows.
#. In *Application / Accounting & Finance*, select *Billing* or *Billing Manager*

To configure this module, you need to:

#. Go to *Configuration / Settings*
#. Under the *Followup Section* of *Accounting* option select either or both of OCA Activity or Outstanding Statement
#. Once selected, you may set default options for the reports.
#. Click *Save*

Removing the wizard from menus follows the same process.
